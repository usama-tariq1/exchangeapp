<?php




class Role extends Database
{
}
