<?php


class Ratesheet extends Database
{
}
