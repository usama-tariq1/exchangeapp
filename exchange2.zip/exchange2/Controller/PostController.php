<?php

session_start();
include './vendor/autoload.php';
// include_once 'db/user.php';
include 'Controller.php';

class PostController extends Controller
{

    public function index()
    {
        include_once './db/Post.php';
        $post = new Post();
        $posts = $post->findAll();
        self::View('feed', compact('posts'));
    }

    public function types()
    {
        include_once './db/Type.php';
        $type = new Type();
        $types = $type->findAll();
        self::View('typepage', compact('types'));
    }
    public function post()
    {
    }
    public function update()
    {
    }
    public function delete()
    {
    }
    public function create()
    {
    }
    public function read()
    {
        include_once './db/Post.php';
        $post = new Post();
        $posts = $post->find(['posts.u_id' => $_SESSION['u_id']]);
        echo json_encode($posts);
        // var_dump($posts);
    }
}
