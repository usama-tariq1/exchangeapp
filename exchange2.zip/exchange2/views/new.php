<div class="c-card">
    <div class="c-head">
        <div class="imgholder"><img src="/assets/images/usama.jpg" class="img"></div>
        <div class="info">
            <div class="name">Usama</div>
            <div class="date">1 Jan 2020</div>
        </div>
        <!-- <img src="icons/3dot.png" class="dots"> -->
        <div class="menu">
            <img src="/assets/icons/delete-icon.png" class="menu__icon" title="Delete">
            <img src="/assets/icons/edit-icon.png" class="menu__icon" title="Edit">

        </div>
    </div>
    <div class="clearfix"></div>

    <div class="body">
        <div class="contract">
            <div class="company">
                <div class="bar"></div>
                <div class="company-name">Some Organization Pvt ltd Multan Pakistan. </div>
                <div class="company-name">Some Organization Pvt ltd </div>
            </div>
            <div class="clearfix"></div>

            <div class="rate">Buy : <span>2000 <span> /bale</span> </span></div>
            <div class="qty">Qty : <span>25 <span> bales</span> </span></div>
        </div>
    </div>

    <div class="clearfix"></div>
</div><!-- c-card ends here -->