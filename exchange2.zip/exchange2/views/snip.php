<div class="c-card">
    <div class="c-head">
        <div class="imgholder"><img src="images/usama.jpg" class="img"></div>
        <div class="info">
            <div class="name">Usama</div>
            <div class="date">1 Jan 2020</div>
        </div>
        <!-- <img src="icons/3dot.png" class="dots"> -->
        <div class="menu">
            <img src="icons/delete-icon.png" class="menu__icon" title="Delete">
            <img src="icons/edit-icon.png" class="menu__icon" title="Edit">

        </div>
    </div>
    <div class="clearfix"></div>

    <div class="body">
        <div class="rate-update">
            <div class="title">
                <div class="rate-of"> Cotton </div>
                <div class="city">Multan</div>
            </div>

            <div class="info">
                <div class="up-rate"> <span><i class="fa fa-chevron-up" aria-hidden="true"></i></span> 3000</div>
                <div class="down-rate"> <span><i class="fa fa-chevron-down" aria-hidden="true"></i></span> 2000
                </div>
            </div>

            <div class="clearfix"></div>

        </div>
    </div>

    <div class="clearfix"></div>
</div><!-- c-card ends here -->