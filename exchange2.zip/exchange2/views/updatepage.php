<div id="addpage" class="functionpage">
    <div class="topbar">
        <div class="title">
            Update
        </div>
    </div>

    <div class="updatepage">

        <div class="box">

            <select name="item" id="" class="txt">
                <option value="0"> Cotton </option>
                <option value="1"> Gold </option>

            </select>

            <select name="country" id="" class="txt">
                <option value="0"> Pakistan </option>
            </select>

            <select name="province" id="" class="txt">
                <option value="0"> Punjab </option>
                <option value="1"> Sindh </option>

            </select>

            <input type="number" placeholder="Local Rate" name="rate" class="txt">

        </div>

        <div class="btnholder">
            <div class="btn">Save</div>
        </div>

    </div>

</div>