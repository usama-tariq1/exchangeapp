<div class="ratesheet">
    <div class="topbar">
        <div class="left"> <img src="/assets/icons/reload-icon.png" class="icon"> </div>
        <div class="right">
            <select name="selector" id="" class="selector">
                <option value="0"> Currency | Commodities </option>
                <option value="1"> Currency </option>
                <option value="2"> Commodities </option>
            </select>
        </div>
    </div>

    <div class="ratecard">
        <div class="left">
            <div class="itemname">Cotton</div>
            <div class="date">25 feb 2020</div>
            <div class="province">Punjab</div>
        </div>
        <div class="right">
            <div class="currency">Rupees</div>
            <div class="universalrate"> <span><img src="/assets/icons/uperrow-icon.png" class="icon"></span> 3000</div>
            <div class="local"> <span><img src="/assets/icons/uperrow-icon.png" class="icon"></span> 3500</div>
        </div>
    </div>

</div>