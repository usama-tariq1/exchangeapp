<div class="navbar">
    <div class="logo">
        <img src="icons/logo.png"  class="img" >
    </div>

    
</div>