<div class="screen">
    <div class="screen__header">
        <div class="screen__header__left">
            <img src="assets/icons/install-icon.png" class="icon">
        </div>
        <div class="screen__header__right">

        </div>
    </div>
    <div class="screen__body">
        <div class="clearfix"></div>
        <div class="imgholder">
            <img src="assets/icons/exchange-circle-icon.png" class="img">
        </div>
        <div class="title"> Exchange </div>
        <div class="subtitle">Real time Rate And Contract Update </div>
        <div class="btnholder">
            <div class="btn" onclick="loadpage('/signup')"> SignUp</div>
            <div class="btn" onclick="loadpage('/login')"> LogIn</div>
        </div>

    </div>
    <div class="screen__footer">

    </div>

</div>