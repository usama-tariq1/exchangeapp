</div>
<script>
    // PullToRefresh.init({
    //     mainElement: '#feeds',
    //     onRefresh: function() {
    //         loadpage('feeds.php');
    //     }
    // });
</script>
</body>

</html>