<div id="addpage" class="functionpage">
    <div class="topbar">
        <div class="title">
            Add Firm
        </div>
    </div>

    <div class="updatepage">

        <div class="box" id="box">

            <form action="" id="addfirmform" method="post">
                <input type="text" placeholder="Firm Name" name="firm_name" required class="txt" id="firmname">


            </form>


        </div>

        <div class="btnholder">
            <div class="btn" onclick="addfirm()">Save</div>
        </div>

    </div>

</div>