<?php


Route::set('/', 'Home@index');

Route::set('/aboutus', 'AboutUs@index');

Route::set('/contact', 'ContactUs');




// Route::setfunc('/contact', function () {
//     echo "Contact";
// });
